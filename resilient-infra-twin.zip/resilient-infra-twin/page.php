<?php get_header();$s=rit_view_slug();
if($s){echo '<div class="ph rv"><h1>'.esc_html(get_the_title()).'</h1></div><div class="view" data-view="'.esc_attr($s).'"></div>';}
else{while(have_posts()){the_post();echo '<article class="card glass post"><h1>'.esc_html(get_the_title()).'</h1>';the_content();echo '</article>';}}
get_footer();
