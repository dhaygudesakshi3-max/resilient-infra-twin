</div></main>
<footer class="ft"><div class="wrap">SIMULATION MODE — Demo Sensor Data. No physical sensors are connected. &copy; <?php echo esc_html(date('Y'));?> Resilient Infra-Twin</div></footer>
<?php wp_footer();?></body></html>
