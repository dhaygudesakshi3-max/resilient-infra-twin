<!doctype html><html <?php language_attributes();?>><head><meta charset="<?php bloginfo('charset');?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head();?></head><body <?php body_class();?>><?php wp_body_open();?>
<div class="sim">SIMULATION MODE — Demo Sensor Data</div>
<header class="hdr"><div class="wrap"><a class="brand" href="<?php echo esc_url(home_url('/'));?>"><i></i>Resilient Infra-Twin</a>
<button class="tg" aria-label="Menu" aria-expanded="false">☰</button>
<nav class="nav" aria-label="Primary"><?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'fallback_cb'=>'rit_fallback_menu']);?></nav></div></header>
<main><div class="wrap">
