<?php get_header();?><div class="view" data-view="home"></div><?php get_footer();?>
