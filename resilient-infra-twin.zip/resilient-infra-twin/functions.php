<?php
if(!defined('ABSPATH'))exit;
function rit_views(){return ['home'=>'Home','dashboard'=>'Dashboard','digital-twin'=>'Digital Twin','sensor-monitoring'=>'Sensor Monitoring','ai-risk-prediction'=>'AI Risk Prediction','knowledge-graph'=>'Knowledge Graph','predictive-maintenance'=>'Predictive Maintenance','alerts'=>'Alerts','infrastructure-assets'=>'Infrastructure Assets','analytics'=>'Analytics','technology'=>'Technology','about'=>'About'];}
function rit_page_url($slug){$p=get_page_by_path($slug);return $slug==='home'?home_url('/'):($p?get_permalink($p):'#');}
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('post-thumbnails');add_theme_support('html5',['search-form','gallery','caption','style','script']);register_nav_menus(['primary'=>'Primary Menu']);});
add_action('widgets_init',function(){register_sidebar(['name'=>'Sidebar','id'=>'sidebar-1','before_widget'=>'<div class="card glass post">','after_widget'=>'</div>','before_title'=>'<h3>','after_title'=>'</h3>']);});
add_action('wp_enqueue_scripts',function(){
 $v=wp_get_theme()->get('Version');$u=get_template_directory_uri();
 wp_enqueue_style('rit-style',get_stylesheet_uri(),[],$v);
 wp_enqueue_style('rit-main',$u.'/assets/css/main.css',['rit-style'],$v);
 wp_enqueue_script('rit-data',$u.'/assets/js/demo-data.js',[],$v,true);
 wp_enqueue_script('rit-app',$u.'/assets/js/app.js',['rit-data'],$v,true);
 $pages=[];foreach(rit_views() as $s=>$t)$pages[$s]=rit_page_url($s);
 wp_localize_script('rit-app','RIT',['pages'=>$pages]);
});
function rit_fallback_menu(){echo '<ul>';foreach(rit_views() as $s=>$t)echo '<li><a href="'.esc_url(rit_page_url($s)).'">'.esc_html($t).'</a></li>';echo '</ul>';}
function rit_view_slug(){if(is_front_page())return 'home';if(is_page()){$s=get_post_field('post_name',get_queried_object_id());if(isset(rit_views()[$s]))return $s;}return '';}
add_action('after_switch_theme',function(){
 $ids=[];
 foreach(rit_views() as $s=>$t){$p=get_page_by_path($s);
  if(!$p){$id=wp_insert_post(['post_title'=>$t,'post_name'=>$s,'post_status'=>'publish','post_type'=>'page','meta_input'=>['_wp_page_template'=>'template-app.php']]);}
  else{$id=$p->ID;update_post_meta($id,'_wp_page_template','template-app.php');}
  $ids[$s]=$id;}
 update_option('show_on_front','page');update_option('page_on_front',$ids['home']);
 $m=wp_get_nav_menu_object('Infra-Twin Main');
 if(!$m){$mid=wp_create_nav_menu('Infra-Twin Main');$i=0;
  foreach($ids as $s=>$id)wp_update_nav_menu_item($mid,0,['menu-item-title'=>rit_views()[$s],'menu-item-object'=>'page','menu-item-object-id'=>$id,'menu-item-type'=>'post_type','menu-item-status'=>'publish','menu-item-position'=>++$i]);
  $loc=get_theme_mod('nav_menu_locations',[]);$loc['primary']=$mid;set_theme_mod('nav_menu_locations',$loc);}
});
