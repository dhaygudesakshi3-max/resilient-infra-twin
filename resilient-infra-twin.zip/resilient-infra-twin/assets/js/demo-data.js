/* EDIT THIS FILE to change demo data. All values are SIMULATED. */
window.RIT_DATA={
 // Sensors: k=name,u=unit,v=value,w=warning threshold,n=live noise,d=decimals
 sensors:[{k:'Vibration',u:'mm/s',v:2.4,w:4,n:.15,d:1},{k:'Strain',u:'με',v:410,w:400,n:6,d:0},{k:'Temperature',u:'°C',v:34,w:45,n:.3,d:1},{k:'Displacement',u:'mm',v:7.2,w:6,n:.12,d:1},{k:'Tilt',u:'°',v:.12,w:.5,n:.01,d:2},{k:'Crack Width',u:'mm',v:.18,w:.3,n:.005,d:2}],
 // Digital-twin components: g=[x,y,w,h] inside the SVG; risk = Low/Medium/High/Critical
 parts:[
 {id:'D1',name:'Bridge Deck D1',h:78,risk:'Medium',fp:18,rd:'Vibration 2.4 mm/s (Normal)',act:'Routine inspection; keep monitoring vibration.',g:[60,130,680,30]},
 {id:'B1',name:'Beam B1',h:90,risk:'Low',fp:6,rd:'Strain 210 με',act:'Routine inspection in 90 days.',g:[60,160,680,14]},
 {id:'C1',name:'Column C1',h:91,risk:'Low',fp:5,rd:'Tilt 0.05°',act:'No action required.',g:[150,174,34,130]},
 {id:'C2',name:'Column C2',h:85,risk:'Low',fp:9,rd:'Strain 260 με',act:'Routine inspection in 90 days.',g:[383,174,34,130]},
 {id:'C4',name:'Column C4',h:67,risk:'High',fp:42,rd:'Strain 410 με (Warning) — Sensor S14',act:'Detailed structural inspection within 7 days.',g:[616,174,34,130]},
 {id:'F1',name:'Foundation F1',h:88,risk:'Low',fp:7,rd:'Settlement 1.1 mm',act:'Annual scour check.',g:[100,304,600,22]},
 {id:'E1',name:'Expansion Joint E1',h:90,risk:'Low',fp:6,rd:'Displacement 3.1 mm',act:'Routine lubrication.',g:[270,124,10,42]},
 {id:'E2',name:'Expansion Joint E2',h:80,risk:'Low',fp:8,rd:'Displacement 7.2 mm (Warning)',act:'Schedule replacement within 30 days.',g:[500,124,10,42]}],
 // Assets: name,type,location,age,health,risk
 assets:[['Bridge A','Bridge','Pune',28,82,'Medium'],['Bridge B','Bridge','Nashik',12,94,'Low'],['Flyover F1','Flyover','Pune',19,90,'Low'],['Flyover F2','Flyover','Mumbai',33,71,'High'],['Tower T1','Building','Pune',9,96,'Low'],['Tower T2','Building','Hyderabad',41,58,'Critical'],['Hospital Block H1','Building','Nagpur',26,88,'Low'],['Bridge C','Bridge','Kolhapur',52,69,'Medium'],['Viaduct V1','Bridge','Surat',15,92,'Low'],['Dam Gate Complex','Dam','Satara',38,89,'Low'],['Flyover F3','Flyover','Thane',8,95,'Low'],['Metro Pier Line M1','Bridge','Pune',6,97,'Low']],
 alerts:[['Critical','Abnormal vibration detected in Deck D1.','Bridge A / D1','Today 09:42'],['High','Increasing strain detected in Column C4.','Bridge A / C4','Today 08:15'],['Medium','Expansion joint displacement above expected range.','Bridge A / E2','Yesterday 21:30'],['Low','Temperature sensor T07 battery at 18%.','Bridge A / T07','2 days ago']],
 maint:[['Bridge A','Column C4','High','Increasing strain','Detailed inspection','Urgent','7 days'],['Bridge A','Expansion Joint E2','Medium','Wear detected','Schedule replacement','Medium','30 days'],['Bridge A','Deck D1','Low','Normal degradation','Routine inspection','Low','90 days'],['Flyover F2','Bearing P3','High','Corrosion progression','Bearing assessment','High','14 days'],['Tower T2','Core Wall W1','Critical','Crack widening','Structural shoring review','Urgent','Today']],
 anomalies:[3,5,2,8,4,6,9],forecast:[7,5,9,6,4,8],inspections:[4,6,5,8,7,9]
};
