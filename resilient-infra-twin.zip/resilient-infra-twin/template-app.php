<?php /* Template Name: Infra-Twin App View */ get_header();$s=rit_view_slug();?>
<div class="ph rv"><h1><?php the_title();?></h1></div><div class="view" data-view="<?php echo esc_attr($s?$s:'about');?>"></div><?php get_footer();?>
