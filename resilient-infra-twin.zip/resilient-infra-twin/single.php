<?php get_header();?><div class="layout"><div><?php while(have_posts()):the_post();?>
<article class="card glass post"><h1><?php the_title();?></h1><?php the_content();?></article><?php endwhile;?></div><?php get_sidebar();?></div><?php get_footer();?>
