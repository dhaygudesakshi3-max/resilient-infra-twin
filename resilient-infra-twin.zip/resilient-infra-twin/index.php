<?php get_header();?><div class="layout"><div><?php if(have_posts()):while(have_posts()):the_post();?>
<article class="card glass post"><h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2><?php the_excerpt();?></article>
<?php endwhile;the_posts_pagination();else:echo '<p>Nothing found.</p>';endif;?></div><?php get_sidebar();?></div><?php get_footer();?>
